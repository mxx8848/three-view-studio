@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
title 三视图工坊
set "NODE_OPTIONS="
set "NODE_PATH="
if not exist "%~dp0app\runtime\node.exe" (
  echo 请先右键压缩包，选择“全部解压”，再双击启动网站。
  pause
  exit /b 1
)
"%~dp0app\runtime\node.exe" "%~dp0app\start.mjs"
if errorlevel 1 (
  pause
  exit /b 1
)
exit /b 0

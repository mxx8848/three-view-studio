import {createServer} from 'node:http';
import {spawn} from 'node:child_process';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
const base=dirname(fileURLToPath(import.meta.url)), host='127.0.0.1';
process.env.SHARE_ONLY='0';
process.env.DB_PATH=resolve(base,'..','学习记录','app.db');
async function run() {
  const {app}=await import('./server.js');
  const bind=port=>new Promise((done,fail)=>{
    const service=createServer(app);
    service.once('error',fail);
    service.listen(port,host,()=>{service.removeListener('error',fail);done(service);});
  });
  let server;
  for(const port of [5178,5180,5181,5182,0]) {
    try {server=await bind(port);break;} catch(e){if(e.code!=='EADDRINUSE'||!port)throw e;}
  }
  const address='http://'+host+':'+server.address().port;
  console.log('三视图工坊已启动：'+address+'\n如果浏览器没有自动打开，请复制上方地址到 Edge 或 Chrome。\n使用期间请保留此窗口；结束时按 Ctrl+C 或关闭窗口。');
  if(process.env.TVS_NO_BROWSER!=='1'){
    const child=spawn(join(process.env.SystemRoot||'C:\\Windows','System32','rundll32.exe'),['url.dll,FileProtocolHandler',address],{windowsHide:true,stdio:'ignore'});
    child.once('error',()=>console.log('请在浏览器中打开 '+address));child.unref();
  }
  const stop=()=>{server.close(()=>process.exit(0));server.closeAllConnections();};
  process.once('SIGINT',stop);process.once('SIGTERM',stop);
}
run().catch(e=>{console.error('启动失败：'+e.message+'\n请先将压缩包全部解压到桌面等可写目录，再双击启动网站。');process.exitCode=1;});